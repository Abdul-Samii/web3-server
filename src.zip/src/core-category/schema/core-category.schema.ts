import { Schema } from 'mongoose';

export const CoreCategorySchema = new Schema({
  name: String,
});
