export class CreateCoreCategoryDto {
  readonly name: string;
}