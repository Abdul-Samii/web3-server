export class CreateTagDto {
  readonly name: string;
}